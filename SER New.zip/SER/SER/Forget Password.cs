﻿using SER.Helpers;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SER
{
    public partial class Forget_Password : Form
    {
        public Forget_Password()
        {
            InitializeComponent();
        }


        private void label1_Click(object sender, EventArgs e)
        {

        }


        private void button1_Click(object sender, EventArgs e)
        {
            bool isError = true;
            if (string.IsNullOrEmpty(textBox1.Text) || textBox1.Text == "Email Address")
            {
                this.errorEmail.Visible = true;
                isError = true;
            }
            else
            {
                this.errorEmail.Visible = false;
                isError = false;
            }
            if (!isError)
            {
                EmailHelper emailHelper = new EmailHelper();
                if (emailHelper.IsValidEmail(this.textBox1.Text))
                {
                    this.errorEmail.Text = "Please wait while email is sending!";
                    this.errorEmail.Visible = true;
                    this.textBox1.Enabled = false;
                    var result = emailHelper.SendEmail(this.textBox1.Text);
                    if (result.Key)
                    {
                        FormLoaderHelper helper = new FormLoaderHelper();
                        helper.loadform(new New_Password());
                    }
                    else
                    {
                        this.errorEmail.Text = result.Value;
                        this.errorEmail.Visible = true;
                        this.textBox1.Enabled = true;
                    }
                }
                else
                {
                    errorEmail.Text = "Valid email is required";
                    errorEmail.Visible = true;
                }
            }

            //Verify v = new Verify();
            //this.Hide();
            //v.Show();
        }



        private void pictureBox1_Click(object sender, EventArgs e)
        {
            pictureBox1.BorderStyle = BorderStyle.None;
        }

        private void textBox1_Enter(object sender, EventArgs e)
        {
            if (textBox1.Text == "Email Address")
            {
                textBox1.Text = "";
                textBox1.ForeColor = Color.Black;
            }
        }

        private void textBox1_Leave(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                textBox1.Text = "Email Address";
                //textBox1.ForeColor = Color.Black;
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
