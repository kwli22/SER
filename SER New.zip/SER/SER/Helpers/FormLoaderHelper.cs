﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SER.Helpers
{
    public class FormLoaderHelper
    {
        public void loadform(object Form)
        {
            Panel mainPanel = new Panel();

            Login form1 = (Login)Application.OpenForms["Login"];

            mainPanel = (Panel)form1.Controls["mainPanel"];

            Button btn = (Button)mainPanel.Controls["button1"];
            PictureBox pb = (PictureBox)mainPanel.Controls["pictureBox1"];
            GroupBox gb = (GroupBox)mainPanel.Controls["groupBox1"];

            if (btn != null)
                mainPanel.Controls.Remove(btn);
            if (gb != null)
                mainPanel.Controls.Remove(gb);
            if (pb != null)
                mainPanel.Controls.Remove(pb);

            if (mainPanel.Controls.Count > 0)
            {

                for (int i = 0; i < mainPanel.Controls.Count; i++)
                {
                    mainPanel.Controls.RemoveAt(i);
                }
                //if (mainPanel.Controls.Find("groupBox1", true).FirstOrDefault() != null)
                //{

                //}
                //mainPanel.Controls.RemoveAt(0);
                //foreach (var item in mainPanel.Controls)
                //{
                //    var ct = item as Control;
                //    mainPanel.Controls.Remove(ct);
                //}
            }
            Form f = Form as Form;
            f.TopLevel = false;
            f.Dock = DockStyle.Fill;

            mainPanel.Controls.Add(f);

            //mainPanel.Controls.Add(f);
            mainPanel.Tag = f;
            f.Show();
        }
    }
}
