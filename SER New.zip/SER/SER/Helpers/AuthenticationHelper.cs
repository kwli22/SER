﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SER.Helpers
{
    public static class AuthenticationHelper
    {
        public static string emailAddress;
        public static void SetEmail(string email)
        {
            emailAddress = email;
        }
        public static string GetEmail()
        {
            return emailAddress;
        }
    }
}
