﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;

namespace SER.Helpers
{
    public class EmailHelper
    {
        private readonly string connectionString = "server=127.0.0.1;port=3308;database=serdb;uid=root;pwd=sasa;";
        public string loggedInUserEmail = "";
        public KeyValuePair<bool, string> SendEmail(string email)
        {
            try
            {
                if (!CheckIfUserExists(email))
                {
                    return new KeyValuePair<bool, string>(false, "Email address doesn't exists. Don't have account? Please Signup");
                }

                var otp = SaveOTPForUser(email);
                if (!string.IsNullOrEmpty(otp))
                {
                    var message = new MailMessage();
                    message.Subject = "";
                    message.To.Add(email);
                    message.From = new MailAddress("noreply@ser.com");
                    message.Body = $"Please use following OTP to update your password {otp}";
                    // set smtp details
                    var smtp = new SmtpClient("smtp.gmail.com");
                    smtp.Port = 25;
                    smtp.EnableSsl = true;
                    smtp.UseDefaultCredentials = false;
                    smtp.Credentials = new NetworkCredential("hamazmairaj143@gmail.com", "5buna9991");
                    smtp.Send(message.From.Address, message.To.FirstOrDefault().Address, message.Subject, message.Body);
                    return new KeyValuePair<bool, string>(true, "Code sent to your email");
                }
                return new KeyValuePair<bool, string>(false, "OTP is not sent, please try again");
            }
            catch (Exception ex)
            {
                return new KeyValuePair<bool, string>(false, "OTP is not sent, please try again");
            }
        }

        public string SaveOTPForUser(string email)
        {
            MySqlConnection cnn = new MySqlConnection(connectionString);
            try
            {
                Random r = new Random();
                var x = r.Next(0, 1000000);
                string s = x.ToString("000000");
                cnn.Open();
                MySqlCommand cmd = new MySqlCommand($"SET SQL_SAFE_UPDATES=0; update Users set SecurityCode={s} where Email='{email}';", cnn);
                cmd.ExecuteNonQuery();
                //using (var reader = cmd.ExecuteReader())
                //{
                //    while (reader.Read())
                //    {
                //        list.Add(new Album()
                //        {
                //            Id = Convert.ToInt32(reader["Id"]),
                //            Name = reader["Name"].ToString(),
                //            ArtistName = reader["ArtistName"].ToString(),
                //            Price = Convert.ToInt32(reader["Price"]),
                //            Genre = reader["genre"].ToString()
                //        });
                //    }
                //}
                cnn.Close();
                return s;
            }
            catch (Exception ex)
            {
                return "";
            }
        }

        public KeyValuePair<bool, string> UpdateUserPassword(string email, string otp, string password)
        {

            if (!CheckIfUserExists(email, otp))
            {
                return new KeyValuePair<bool, string>(false, "Email or OTP is incorrect, please check agian");
            }

            MySqlConnection cnn = new MySqlConnection(connectionString);
            try
            {
                cnn.Open();
                MySqlCommand cmd = new MySqlCommand($"SET SQL_SAFE_UPDATES=0; update Users set UserPassword='{password}' where SecurityCode='{otp}' and Email='{email}';", cnn);
                cmd.ExecuteNonQuery();
                cnn.Close();
                return new KeyValuePair<bool, string>(true, "Updated successfully");
            }
            catch (Exception ex)
            {
                return new KeyValuePair<bool, string>(false, "Data is not saved, please try again");
            }
        }

        public KeyValuePair<bool, string> SaveNewUser(string firstName, string lastName, string password, string email)
        {
            try
            {
                if(IsNumeric(firstName) || IsNumeric(lastName))
                {
                    return new KeyValuePair<bool, string>(false, "Please enter a valid first and last name");
                }

                if (CheckIfUserExists(email))
                {
                    return new KeyValuePair<bool, string>(false, "Please use another email, there's already an account with same email");
                }

                string query = $"insert into Users (LastName ,FirstName ,UserPassword ,Email) values('{lastName}', '{firstName}', '{password}', '{email}');";
                MySqlConnection cnn = new MySqlConnection(connectionString);
                cnn.Open();
                MySqlCommand cmd = new MySqlCommand(query, cnn);
                cmd.ExecuteNonQuery();
                cnn.Close();
                return new KeyValuePair<bool, string>(true, "Signup successfull!");
            }
            catch (Exception ex)
            {
                return new KeyValuePair<bool, string>(false, "Please try again");
            }
        }

        public bool IsNumeric(string str) => int.TryParse(str, out _);

        public void UpdateUser(string email, string firstName, string lastName, string password)
        {
            try
            {
                string query = $"SET SQL_SAFE_UPDATES=0; update users set FirstName='{firstName}', LastName='{lastName}', UserPassword='{password}' where Email='{email}'";

                MySqlConnection cnn = new MySqlConnection(connectionString);
                cnn.Open();
                MySqlCommand cmd = new MySqlCommand(query, cnn);
                var reader = cmd.ExecuteNonQuery();
                cnn.Close();
            }
            catch (Exception ex)
            {
                
            }
        }

        public UserVM GetUser(string email)
        {
            var user = new UserVM();
            try
            {
                string query = $"select FirstName, LastName, Email, UserPassword from users where email='{email}';";

                MySqlConnection cnn = new MySqlConnection(connectionString);
                cnn.Open();
                MySqlCommand cmd = new MySqlCommand(query, cnn);
                var reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    user.FirstName = reader.GetString(0);
                    user.LastName = reader.GetString(1);
                    user.Email = reader.GetString(2);
                    user.Password = reader.GetString(3);
                }
                cnn.Close();
                return user;
            }
            catch (Exception ex)
            {
                return new UserVM();
            }
        }
        public bool CheckIfUserExists(string email, string otp)
        {
            try
            {
                string query = $"select count(*) as count from users where email='{email}' and SecurityCode='{otp}';";

                MySqlConnection cnn = new MySqlConnection(connectionString);
                cnn.Open();
                MySqlCommand cmd = new MySqlCommand(query, cnn);
                var reader = cmd.ExecuteReader();
                int result = 0;
                while (reader.Read())
                {
                    result = Convert.ToInt32(reader.GetInt32("count"));
                }
                cnn.Close();
                if (result <= 0)
                    return false;
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }


        public bool CheckIfUserExists(string email)
        {
            try
            {
                string query = $"select count(*) as count from users where email='{email}';";

                MySqlConnection cnn = new MySqlConnection(connectionString);
                cnn.Open();
                MySqlCommand cmd = new MySqlCommand(query, cnn);
                var reader = cmd.ExecuteReader();
                int result = 0;
                while (reader.Read())
                {
                    result = Convert.ToInt32(reader.GetInt32("count"));
                }
                cnn.Close();
                if (result <= 0)
                    return false;
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }


        public bool LoginCheckUserExists(string email, string password)
        {
            try
            {
                string query = $"select count(*) as count from users where email='{email}' and UserPassword = '{password}'";

                MySqlConnection cnn = new MySqlConnection(connectionString);
                cnn.Open();
                MySqlCommand cmd = new MySqlCommand(query, cnn);
                var reader = cmd.ExecuteReader();
                int result = 0;
                while (reader.Read())
                {
                    result = Convert.ToInt32(reader.GetInt32("count"));
                }
                cnn.Close();
                if (result <= 0)
                    return false;
                this.loggedInUserEmail = email;
                AuthenticationHelper.SetEmail(email);
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public bool IsValidEmail(string email)
        {
            try
            {
                var arr = email.Split('@');
                if (arr.Length > 1 && arr[1].Contains(".") && arr[1].Split('.').Length > 2)
                {
                    return false;
                }
                var emailAddressAttribute = new EmailAddressAttribute();
                return emailAddressAttribute.IsValid(email);
            }
            catch (Exception ex)
            {

                return false;
            }
        }
    }
}
