﻿using SER.Helpers;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SER
{
    public partial class Update : Form
    {
        public Update()
        {
            InitializeComponent();
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            pictureBox1.BorderStyle = BorderStyle.None;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            bool isError = true;
            if (string.IsNullOrEmpty(textBox1.Text) || textBox1.Text == "First Name")
            {
                errorFirstName.Visible = true;
                isError = true;
            }
            else
            {
                errorFirstName.Visible = false;
                isError = false;
            }
            if (string.IsNullOrEmpty(textBox2.Text) || textBox2.Text == "Last Name")
            {
                errorLastName.Visible = true;
                isError = true;
            }
            else
            {
                errorLastName.Visible = false;
                isError = false;
            }
            if (string.IsNullOrEmpty(textBox3.Text) || textBox3.Text == "Email")
            {
                errorEmail.Visible = true;
                isError = true;
            }
            else
            {
                errorEmail.Visible = false;
                isError = false;
            }

            if (string.IsNullOrEmpty(textBox6.Text) || textBox6.Text == "Current Password")
            {
                errorCurrentPassword.Visible = true;
                isError = true;
            }
            else
            {
                errorCurrentPassword.Visible = false;
                isError = false;
            }
            if (string.IsNullOrEmpty(textBox6.Text) || textBox6.Text == "New Password")
            {
                errorNewPassword.Visible = true;
                isError = true;
            }
            else
            {
                errorNewPassword.Visible = false;
                isError = false;
            }
            if (string.IsNullOrEmpty(textBox6.Text) || textBox6.Text == "Confirm Password")
            {
                errorConfirmPassword.Visible = true;
                isError = true;
            }
            else
            {
                errorConfirmPassword.Visible = false;
                isError = false;
            }
            if (!isError)
            {
                FormLoaderHelper helper = new FormLoaderHelper();
                helper.loadform(new Edit_Profile());
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FormLoaderHelper helper = new FormLoaderHelper();
            helper.loadform(new Edit_Profile());
            //Edit_Profile p = new Edit_Profile();
            //this.Hide();
            //p.Show();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void errorFirstName_Click(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
