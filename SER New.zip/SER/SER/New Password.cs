﻿using SER.Helpers;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SER
{
    public partial class New_Password : Form
    {
        public New_Password()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_Enter(object sender, EventArgs e)
        {
            if (textBox1.Text == "Password")

            {
                textBox1.Text = "";
                textBox1.ForeColor = Color.Black;
            }
        }

        private void textBox1_Leave(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                textBox1.Text = "Password";
                textBox1.ForeColor = Color.Silver;
            }
        }

        private void textBox2_Enter(object sender, EventArgs e)
        {
            if (textBox2.Text == "Confirm Password")
            {
                textBox2.Text = "";
                textBox2.ForeColor = Color.Black;
            }
        }

        private void textBox2_Leave(object sender, EventArgs e)
        {
            if (textBox2.Text == "")
            {
                textBox2.Text = "Confirm Password";
                textBox2.ForeColor = Color.Silver;
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            pictureBox1.BorderStyle = BorderStyle.None;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FormLoaderHelper helper = new FormLoaderHelper();
            helper.loadform(new Login(true));
        }

        private void button2_Click(object sender, EventArgs e)
        {
            bool isError = true;
            if (string.IsNullOrEmpty(textBox1.Text) || textBox1.Text == "Password")
            {
                errorPassword.Visible = true;
                isError = true;
            }
            else
            {
                errorPassword.Visible = false;
                isError = false;
            }

            if (string.IsNullOrEmpty(textBox2.Text) || textBox2.Text == "Confirm Password")
            {
                errorConfirmPassword.Visible = true;
                isError = true;
            }
            else
            {
                errorConfirmPassword.Visible = false;
                isError = false;
            }

            if (string.IsNullOrEmpty(textBox3.Text) || textBox3.Text == "Confirm Password")
            {
                errorOTP.Visible = true;
                isError = true;
            }
            else
            {
                errorOTP.Visible = false;
                isError = false;
            }

            if (string.IsNullOrEmpty(textBox4.Text) || textBox4.Text == "Email Address")
            {
                errorEmail.Visible = true;
                isError = true;
            }
            else
            {
                errorEmail.Visible = false;
                isError = false;
            }

            if (textBox1.Text != textBox2.Text)
            {
                this.errorConfirmPassword.Text = "Password and Confirm Password should be same";
                this.errorConfirmPassword.Visible = true;
                isError = true;
            }

            if (!isError)
            {
                errorConfirmPassword.Text = "Please wait while saving data";
                errorConfirmPassword.Visible = true;
                textBox1.Enabled = false;
                textBox2.Enabled = false;
                textBox3.Enabled = false;
                textBox4.Enabled = false;


                EmailHelper emailHelper = new EmailHelper();
                var result = emailHelper.UpdateUserPassword(textBox4.Text, textBox3.Text, textBox2.Text);
                if (!result.Key)
                {
                    errorEmail.Text = result.Value;
                    errorConfirmPassword.Visible = false;
                    textBox1.Enabled = true;
                    textBox2.Enabled = true;
                    textBox3.Enabled = true;
                    textBox4.Enabled = true;
                }
                else
                {
                    FormLoaderHelper helper = new FormLoaderHelper();
                    helper.loadform(new Login(true));
                }
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void New_Password_Load(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            if(textBox3.Text=="" || textBox3.Text == "OTP")
            {
                textBox3.Text = "";
            }
        }

        private void textBox4_Leave(object sender, EventArgs e)
        {
            if (textBox4.Text == "")
                textBox4.Text = "Email Address";

            textBox4.ForeColor = Color.Silver;
        }

        private void textBox4_Enter(object sender, EventArgs e)
        {
            if (textBox4.Text == "Email Address")
                textBox4.Text = "";
            textBox4.ForeColor = Color.Black;
        }

        private void textBox3_Enter(object sender, EventArgs e)
        {
            if (textBox3.Text == "OTP")
                textBox3.Text = "";
            textBox3.ForeColor = Color.Black;
        }

        private void textBox3_Leave(object sender, EventArgs e)
        {
            if (textBox3.Text == "")
                textBox3.Text = "OTP";

            textBox3.ForeColor = Color.Silver;
        }
    }
}
