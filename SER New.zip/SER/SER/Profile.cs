﻿using SER.Helpers;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SER
{
    public partial class Edit_Profile : Form
    {
        public Edit_Profile()
        {
            InitializeComponent();
            this.textBox1.Text = AuthenticationHelper.GetEmail();
            if (!string.IsNullOrEmpty(AuthenticationHelper.GetEmail()))
            {
                EmailHelper emailHelper = new EmailHelper();
                var data = emailHelper.GetUser(AuthenticationHelper.GetEmail());
                this.textBox1.Text = data.FirstName ?? "";
                this.textBox2.Text = data.LastName ?? "";
                this.textBox3.Text = data.Email ?? "";
                this.textBox4.Text = data.Password ?? "";
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            bool isError = true;
            if (string.IsNullOrEmpty(textBox1.Text) || textBox1.Text == "First Name")
            {
                errorFirstName.Visible = true;
                isError = true;
            }
            else
            {
                errorFirstName.Visible = false;
                isError = false;
            }

            if (string.IsNullOrEmpty(textBox2.Text) || textBox2.Text == "Last Name")
            {
                errorLastName.Visible = true;
                isError = true;
            }
            else
            {
                errorLastName.Visible = false;
                isError = false;
            }

            if (string.IsNullOrEmpty(textBox3.Text) || textBox3.Text == "Email")
            {
                errorEmail.Visible = true;
                isError = true;
            }
            else
            {
                errorEmail.Visible = false;
                isError = false;
            }

            if (string.IsNullOrEmpty(textBox4.Text) || textBox4.Text == "Password")
            {
                errorPassword.Visible = true;
                isError = true;
            }
            else
            {
                errorPassword.Visible = false;
                isError = false;
            }
            if (!isError)
            {
                //FormLoaderHelper helper = new FormLoaderHelper();
                //helper.loadform(new Update());

                EmailHelper emailHelper = new EmailHelper();
                emailHelper.UpdateUser(this.textBox3.Text, this.textBox1.Text, this.textBox2.Text, this.textBox4.Text);
                MessageBox.Show("Updated Successfully!");
            }
            //Edit_Profile p = new Edit_Profile();
            //this.Hide();
            //p.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FormLoaderHelper helper = new FormLoaderHelper();
            helper.loadform(new Home());
        }

        private void button3_Click(object sender, EventArgs e)
        {
            FormLoaderHelper helper = new FormLoaderHelper();
            helper.loadform(new Outcomes());
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FormLoaderHelper helper = new FormLoaderHelper();
            helper.loadform(new Edit_Profile());
        }

        private void button4_Click(object sender, EventArgs e)
        {
            FormLoaderHelper helper = new FormLoaderHelper();
            helper.loadform(new Help());
        }

        private void button5_Click(object sender, EventArgs e)
        {
            FormLoaderHelper helper = new FormLoaderHelper();
            helper.loadform(new Logout());
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            FormLoaderHelper helper = new FormLoaderHelper();
            helper.loadform(new Home());
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            FormLoaderHelper helper = new FormLoaderHelper();
            helper.loadform(new Outcomes());
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            FormLoaderHelper helper = new FormLoaderHelper();
            helper.loadform(new Edit_Profile());
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            FormLoaderHelper helper = new FormLoaderHelper();
            helper.loadform(new Help());
        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            FormLoaderHelper helper = new FormLoaderHelper();
            helper.loadform(new Logout());
        }

        private void Edit_Profile_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void errorLastName_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click_2(object sender, EventArgs e)
        {

        }

        private void button1_Click_2(object sender, EventArgs e)
        {
            FormLoaderHelper helper = new FormLoaderHelper();
            helper.loadform(new Home());
        }

        private void button5_Click_2(object sender, EventArgs e)
        {
            FormLoaderHelper helper = new FormLoaderHelper();
            helper.loadform(new Logout());
        }

        private void button4_Click_2(object sender, EventArgs e)
        {
            FormLoaderHelper helper = new FormLoaderHelper();
            helper.loadform(new Help());
        }

        private void button3_Click_2(object sender, EventArgs e)
        {
            FormLoaderHelper helper = new FormLoaderHelper();
            helper.loadform(new Outcomes());
        }

        private void button2_Click_3(object sender, EventArgs e)
        {
            FormLoaderHelper helper = new FormLoaderHelper();
            helper.loadform(new Edit_Profile());
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void button1_Click_3(object sender, EventArgs e)
        {
            FormLoaderHelper helper = new FormLoaderHelper();
            helper.loadform(new Home());
        }

        private void button3_Click_3(object sender, EventArgs e)
        {
            FormLoaderHelper helper = new FormLoaderHelper();
            helper.loadform(new Outcomes());
        }

        private void button2_Click_4(object sender, EventArgs e)
        {
            FormLoaderHelper helper = new FormLoaderHelper();
            helper.loadform(new Edit_Profile());
        }

        private void button4_Click_3(object sender, EventArgs e)
        {
            FormLoaderHelper helper = new FormLoaderHelper();
            helper.loadform(new Help());
        }

        private void button5_Click_3(object sender, EventArgs e)
        {
            FormLoaderHelper helper = new FormLoaderHelper();
            helper.loadform(new Logout());
        }

        private void label1_Click_2(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
