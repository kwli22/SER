﻿using SER.Helpers;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SER
{
    public partial class Welcome : Form
    {
        System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();
        public Welcome()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            FormLoaderHelper helper = new FormLoaderHelper();
            helper.loadform(new Home());
        }

        private void Welcome_Load(object sender, EventArgs e)
        {
            timer.Interval = 3000;
            timer.Tick += new EventHandler(timer_Tick);
            timer.Start();
        }

        void timer_Tick(object sender, EventArgs e)
        {
            FormLoaderHelper helper = new FormLoaderHelper();
            helper.loadform(new Home());
            timer.Stop();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
