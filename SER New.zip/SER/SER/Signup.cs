﻿using SER.Helpers;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SER
{
    public partial class Signup : Form
    {
        public Signup()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            EmailHelper emailHelper = new EmailHelper();
            bool isError = true;
            if (string.IsNullOrEmpty(textBox1.Text) || textBox1.Text == "First Name" || emailHelper.IsNumeric(textBox1.Text))
            {
                errorFirstName.Visible = true;
                isError = true;
            }
            //else
            //{
            //    errorFirstName.Visible = false;
            //    isError = false;
            //}

            if (string.IsNullOrEmpty(textBox2.Text) || textBox2.Text == "Last Name" || emailHelper.IsNumeric(textBox2.Text))
            {
                errorLastName.Visible = true;
                isError = true;
            }
            //else
            //{
            //    errorLastName.Visible = false;
            //    isError = false;
            //}

            if (string.IsNullOrEmpty(textBox3.Text) || textBox3.Text == "Email")
            {
                errorEmail.Visible = true;
                errorEmail.Text = "Please enter email";
                isError = true;
            }
            else
            {
                if (!emailHelper.IsValidEmail(textBox3.Text))
                {
                    errorEmail.Visible = true;
                    errorEmail.Text = "Invalid email address";
                    isError = true;
                }
                //else
                //{
                //    errorEmail.Visible = false;
                //    isError = false;
                //}
            }

            if (string.IsNullOrEmpty(textBox4.Text) || textBox4.Text == "Password")
            {
                errorPassword.Visible = true;
                isError = true;
            }
            //else
            //{
            //    errorPassword.Visible = false;
            //    isError = false;
            //}

            if (string.IsNullOrEmpty(textBox5.Text) || textBox5.Text == "Confirm Password")
            {
                errorConfirmPassword.Visible = true;
                isError = true;
            }
            //else
            //{
            //    errorConfirmPassword.Visible = false;
            //    isError = false;
            //}

            if (textBox4.Text != textBox5.Text)
            {
                errorConfirmPassword.Text = "Password and Confirm password should be same";
                errorConfirmPassword.Visible = true;
                isError = true;
            }



            if (!isError)
            {
                var result = emailHelper.SaveNewUser(textBox1.Text, textBox2.Text, textBox4.Text, textBox3.Text);
                if (result.Key)
                {
                    FormLoaderHelper helper = new FormLoaderHelper();
                    helper.loadform(new Login(true));
                }
                else
                {
                    errorConfirmPassword.Text = result.Value;
                    errorConfirmPassword.Visible = true;
                }
            }

            //Login li = new Login();
            //this.Hide();
            //li.Show();
        }

        private void textBox1_Leave(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                textBox1.Text = "First Name";
                textBox1.ForeColor = Color.Silver;
            }
        }

        private void textBox2_Enter(object sender, EventArgs e)
        {
            if (textBox2.Text == "Last Name")

            {
                textBox2.Text = "";
                textBox2.ForeColor = Color.Black;
            }
        }

        private void textBox3_Enter(object sender, EventArgs e)
        {
            if (textBox3.Text == "Email")

            {
                textBox3.Text = "";
                textBox3.ForeColor = Color.Black;
            }
        }

        private void textBox4_Enter(object sender, EventArgs e)
        {
            if (textBox4.Text == "Password")

            {
                textBox4.Text = "";
                textBox4.ForeColor = Color.Black;
            }
        }

        private void textBox5_Enter(object sender, EventArgs e)
        {
            if (textBox5.Text == "Confirm Password")

            {
                textBox5.Text = "";
                textBox5.ForeColor = Color.Black;
            }
        }

        private void textBox1_Enter(object sender, EventArgs e)
        {
            if (textBox1.Text == "First Name")

            {
                textBox1.Text = "";
                textBox1.ForeColor = Color.Black;
            }
        }

        private void textBox2_Leave(object sender, EventArgs e)
        {
            if (textBox2.Text == "")
            {
                textBox2.Text = "Last Name";
                textBox2.ForeColor = Color.Silver;
            }
        }

        private void textBox3_Leave(object sender, EventArgs e)
        {
            if (textBox3.Text == "")
            {
                textBox3.Text = "Email";
                textBox3.ForeColor = Color.Silver;
            }
        }

        private void textBox4_Leave(object sender, EventArgs e)
        {
            if (textBox4.Text == "")
            {
                textBox4.Text = "Password";
                textBox4.ForeColor = Color.Silver;
            }
        }

        private void textBox5_Leave(object sender, EventArgs e)
        {
            if (textBox5.Text == "")
            {
                textBox5.Text = "Confirm Password";
                textBox5.ForeColor = Color.Silver;
            }
            else
            {
                if (textBox4.Text != textBox5.Text)
                {
                    errorConfirmPassword.Text = "Password and Confirm password should be same";
                }
            }
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {
            pictureBox1.BorderStyle = BorderStyle.None;
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            FormLoaderHelper helper = new FormLoaderHelper();
            helper.loadform(new Login(true));
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void errorFirstName_Click(object sender, EventArgs e)
        {

        }

        private void errorLastName_Click(object sender, EventArgs e)
        {

        }

    }
}
