﻿using SER.Helpers;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SER
{
    public partial class Home : Form
    {
        private Welcome welcomeForm = null;
        public Home(Form mainForm = null)
        {
            if (mainForm != null)
            {
                welcomeForm = mainForm as Welcome;
            }
            InitializeComponent();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                textBox1.Text = ofd.FileName;
            }
        }
        private void Home_Enter(object sender, EventArgs e)
        {

        }
        private void textBox1_Enter(object sender, EventArgs e)
        {
            if (textBox1.Text == "Choose file")

            {
                textBox1.Text = "";
                textBox1.ForeColor = Color.Black;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FormLoaderHelper helper = new FormLoaderHelper();
            helper.loadform(new Home());
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FormLoaderHelper helper = new FormLoaderHelper();
            helper.loadform(new Edit_Profile());
        }

        private void button4_Click(object sender, EventArgs e)
        {
            FormLoaderHelper helper = new FormLoaderHelper();
            helper.loadform(new Help());
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_Leave(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                textBox1.Text = "Choose File";
                textBox1.ForeColor = Color.Silver;
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            pictureBox1.BorderStyle = BorderStyle.None;
        }

        private void button3_Click(object sender, EventArgs e)
        {

            FormLoaderHelper helper = new FormLoaderHelper();
            helper.loadform(new Outcomes());
        }

        private void button5_Click(object sender, EventArgs e)
        {
            FormLoaderHelper helper = new FormLoaderHelper();
            helper.loadform(new Logout());
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if(this.textBox1.Text!=""&& this.textBox1.Text != "Choose File"&& !string.IsNullOrEmpty(this.textBox1.Text))
            {
                FormLoaderHelper helper = new FormLoaderHelper();
                helper.loadform(new Outcomes());
                errorFile.Visible = false;
            }
            else
            {
                errorFile.Visible = true;
            }

        }

        private void Home_Load(object sender, EventArgs e)
        {
            //if (this.welcomeForm != null)
            //{
            //    this.welcomeForm.timer.Stop();
            //}
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_Enter_1(object sender, EventArgs e)
        {
            if(this.textBox1.Text== "Choose File")
            {
                this.textBox1.Text = "";
            }
        }

        private void textBox1_FontChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_Leave_1(object sender, EventArgs e)
        {
            if (this.textBox1.Text == "")
            {
                this.textBox1.Text = "Choose File";
            }
        }
    }
}
