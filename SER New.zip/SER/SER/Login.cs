﻿using SER.Helpers;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SER
{
    public partial class Login : Form
    {
        private Starting StartingForm = null;
        //public Login(Form mainForm = null)
        //{
        //    if (mainForm != null)
        //    {
        //        StartingForm = mainForm as Starting;
        //    }
        //}
        private object errorMsgEmail;

        public object Email { get; private set; }

        public Login(bool? hideBorder=null)
        {

            InitializeComponent();
            if (hideBorder.HasValue && hideBorder.Value==true)
            {
                this.FormBorderStyle = FormBorderStyle.None;
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            Forget_Password FP = new Forget_Password();
            FP.Show();
        }

        private void textBox1_Enter(object sender, EventArgs e)
        {
            if (textBox1.Text == "Email")

            {
                textBox1.Text = "";
                textBox1.ForeColor = Color.Black;
            }
        }

        private void textBox1_Leave(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                textBox1.Text = "Email";
                textBox1.ForeColor = Color.Silver;
            }
        }

        private void textBox2_Enter(object sender, EventArgs e)
        {
            if (textBox2.Text == "Password")

            {
                textBox2.Text = "";
                textBox2.ForeColor = Color.Black;
            }
        }

        private void textBox2_Leave(object sender, EventArgs e)
        {
            if (textBox2.Text == "")
            {
                textBox2.Text = "Password";
                textBox2.ForeColor = Color.Silver;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            bool isError = true;

            if (string.IsNullOrEmpty(textBox1.Text) || textBox1.Text == "Email")
            {
                errorEmail.Visible = true;
                isError = true;
            }
            else
            {
                errorEmail.Visible = false;
                isError = false;
            }

            if (string.IsNullOrEmpty(textBox2.Text) || textBox2.Text == "Password")
            {
                errorPassword.Visible = true;
                isError = true;
            }
            else
            {
                errorPassword.Visible = false;
                isError = false;
            }
            if (!isError)
            {
                EmailHelper emailHelper = new EmailHelper();
                if(emailHelper.LoginCheckUserExists(textBox1.Text, textBox2.Text))
                {
                    FormLoaderHelper helper = new FormLoaderHelper();
                    helper.loadform(new Welcome());
                }
                else
                {
                    errorEmail.Text = "Email or password incorrect";
                    errorEmail.Visible = true;
                }
            }

            //Welcome wl = new Welcome();
            //this.Hide();
            //wl.Show();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            FormLoaderHelper helper = new FormLoaderHelper();
            helper.loadform(new Forget_Password());
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            FormLoaderHelper helper = new FormLoaderHelper();
            helper.loadform(new Signup());
        }

        private void Login_Load(object sender, EventArgs e)
        {
            //if (this.StartingForm != null)
            //{
            //    this.StartingForm.timer.Stop();
            //}
        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {
 
        }

        private void pictureBox1_Click_2(object sender, EventArgs e)
        {
            pictureBox1.BorderStyle = BorderStyle.None;
        }

        private void mainPanel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void errorEmail_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}